def funcao_modulo1():
    return "ESSE dado veio do modulo test"