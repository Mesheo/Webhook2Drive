import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='mesheo',
    application_name='webhook2drive',
    app_uid='YgFyTdq1DnNGbc8nRq',
    org_uid='4da27546-983e-4593-b9e7-dde39ace09e0',
    deployment_uid='2c034549-c8dd-428a-9384-33cf7bc56979',
    service_name='webhook2drive',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'webhook2drive-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
